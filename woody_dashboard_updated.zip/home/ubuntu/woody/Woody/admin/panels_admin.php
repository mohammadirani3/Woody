<?php include_once('..\config.php');
 ?>

<div class="row">

<?php

$result1 = getSideOrders();
$num1 = mysqli_affected_rows($conn);

?>


<div class="col-lg-4 col-md-6">
<div class="panel panel-yellow">
<div class="panel-heading">
	<div class="row">
		<div class="col-xs-3">
			<i class="fa fa-shopping-cart fa-5x"></i>
		</div>
		<div class="col-xs-9 text-right">
			<div class="huge"><?php echo $num1; ?></div>
			<div>New Orders!</div>
		</div>
	</div>
</div>
<a href="orders.php">
	<div class="panel-footer">
		<span class="pull-left">View Details</span>
		<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
		<div class="clearfix"></div>
	</div>
</a>
</div>
</div>


<?php

$result2 = getSideProducts();
$num2 = mysqli_affected_rows($conn);

?>



<div class="col-lg-4 col-md-6">
<div class="panel panel-red">
<div class="panel-heading">
	<div class="row">
		<div class="col-xs-3">
			<i class="fa fa-support fa-5x"></i>
		</div>
		<div class="col-xs-9 text-right">
			<div class="huge"><?php echo $num2; ?></div>
			<div>Products!</div>
		</div>
	</div>
</div>
<a href="products.php">
	<div class="panel-footer">
		<span class="pull-left">View Details</span>
		<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
		<div class="clearfix"></div>
	</div>
</a>
</div>
</div>

<?php

$result3 = getSideCategories();
$num3 = mysqli_affected_rows($conn);

?>


<div class="col-lg-4 col-md-6">
<div class="panel panel-green">
<div class="panel-heading">
	<div class="row">
		<div class="col-xs-3">
			<i class="fa fa-tasks fa-5x"></i>
		</div>
		<div class="col-xs-9 text-right">
			<div class="huge"><?php echo $num3 ?></div>
			<div>Categories!</div>
		</div>
	</div>
</div>
<a href="categories.php">
	<div class="panel-footer">
		<span class="pull-left">View Details</span>
		<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
		<div class="clearfix"></div>
	</div>
</a>
</div>
</div>


</div>

