<?php
require 'vendor/autoload.php'; 

// IMPORTANT: Replace with your actual client ID and secret
$clientId = 'ATsSiqbGc-RIT6oqdzKJObbWvYPoeVszUftm85Gx-11nRVzRMnTa3mxyIoImWf0W9HqUeHyfAA0Sw85a'; // Replace with your Sandbox Client ID
$clientSecret = 'EK_Ltt65ktza28kYYwBp8i4NNYp2sttH6ys18I-J9FchX9NCKH3VzNLMmmvoNlxuXa_GebwFag_HiJJi'; // Replace with your Sandbox Client Secret

// Database Configuration (replace with your details)
$dbHost = 'localhost';
$dbUsername = 'root'; // Use a dedicated DB user in production
$dbPassword = ''; // Use a strong password in production
$dbName = 'woody_ebus'; // Make sure this matches your database name in config.php and woody_ebus.sql

// Establish Database Connection
$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Check Connection
if ($conn->connect_error) {
    // Log error instead of dying in production
    die("Connection failed: " . $conn->connect_error);
}

// Configure PayPal Environment
$environment = new \PayPalCheckoutSdk\Core\SandboxEnvironment($clientId, $clientSecret);
$client = new \PayPalCheckoutSdk\Core\PayPalHttpClient($environment);

// Get Product ID from URL
if (!isset($_GET['product_id']) || !filter_var($_GET['product_id'], FILTER_VALIDATE_INT)) {
    die("Invalid Product ID.");
}
$productId = (int)$_GET['product_id']; 

// Fetch Product Details from Database
$productQuery = "SELECT * FROM products WHERE id = ?";
$productStmt = $conn->prepare($productQuery);
if (!$productStmt) {
    die("Error preparing product query: " . $conn->error);
}
$productStmt->bind_param("i", $productId);
$productStmt->execute();
$productResult = $productStmt->get_result();

if ($productResult->num_rows === 0) {
    die("Product not found.");
}
$product = $productResult->fetch_assoc();
$productStmt->close();

// --- Create PayPal Order ---
$request = new \PayPalCheckoutSdk\Orders\OrdersCreateRequest();
$request->prefer('return=representation');

// Define Application Context (Return URLs)
// IMPORTANT: Replace 'http://localhost/woody/' with your actual domain and path in production
$baseUrl = "http://localhost/woody/"; // Adjust this based on your actual deployment URL structure
$returnUrl = $baseUrl . "thankyou.php";
$cancelUrl = $baseUrl . "products.php"; // Or a dedicated cancellation page

$request->body = [
    'intent' => 'CAPTURE',
    'application_context' => [
        'return_url' => $returnUrl,
        'cancel_url' => $cancelUrl,
        'brand_name' => 'Woody Furniture',
        'user_action' => 'PAY_NOW',
    ],
    'purchase_units' => [[
        'description' => $product['name'], // Add product description
        'amount' => [
            'currency_code' => 'USD', // Ensure this matches your PayPal account currency
            'value' => $product['price'],
            // Optional: Breakdown amount if needed (e.g., item_total, tax_total)
            // 'breakdown' => [
            //     'item_total' => [
            //         'currency_code' => 'USD',
            //         'value' => $product['price']
            //     ]
            // ]
        ],
        // Optional: Add items array for detailed breakdown
        // 'items' => [
        //     [
        //         'name' => $product['name'],
        //         'quantity' => '1',
        //         'unit_amount' => [
        //             'currency_code' => 'USD',
        //             'value' => $product['price']
        //         ]
        //     ]
        // ]
    ]]
];

try {
    // Execute the request to create the order
    $response = $client->execute($request);
    $orderId = $response->result->id;

    // --- Record Pending Payment in Database ---
    $paymentAmount = $product['price'];
    $paymentStatus = 'PENDING'; // Initial status
    $transactionId = $orderId; // Use PayPal Order ID as transaction ID

    $paymentQuery = "INSERT INTO payments (product_id, payment_amount, payment_status, transaction_id, payment_date)
                    VALUES (?, ?, ?, ?, NOW())";
    $paymentStmt = $conn->prepare($paymentQuery);
    if (!$paymentStmt) {
        die("Error preparing payment query: " . $conn->error);
    }
    // Assuming product_id is integer, amount is decimal/float, status and tx_id are strings
    $paymentStmt->bind_param("idss", $productId, $paymentAmount, $paymentStatus, $transactionId);
    
    if (!$paymentStmt->execute()) {
        // Log error instead of dying in production
        die("Error executing payment insert: " . $paymentStmt->error);
    }
    $paymentStmt->close();

    // --- Redirect User to PayPal for Approval ---
    $approvalUrl = null;
    foreach ($response->result->links as $link) {
        if ($link->rel == 'approve') {
            $approvalUrl = $link->href;
            break;
        }
    }

    if ($approvalUrl) {
        header("Location: " . $approvalUrl);
        exit;
    } else {
        die("Could not find PayPal approval URL.");
    }

} catch (\PayPalHttp\HttpException $e) {
    // Handle API errors (e.g., validation errors, authentication issues)
    echo "PayPal API Error: <pre>" . $e->getMessage() . "</pre> Status Code: " . $e->statusCode;
    // You might want to log $e->result for more details
    // var_dump($e->result);
} catch (Exception $e) {
    // Handle other errors (e.g., database connection, file loading)
    echo "General Error: " . $e->getMessage();
}

$conn->close();
?>
