-- SQL Script to update Woody's database schema to match Cakezone's structure
-- Generated on June 2, 2025

-- First, make a backup of the current tables (recommended to run before applying changes)
-- CREATE TABLE categories_backup AS SELECT * FROM categories;
-- CREATE TABLE products_backup AS SELECT * FROM products;
-- CREATE TABLE users_backup AS SELECT * FROM users;
-- CREATE TABLE payments_backup AS SELECT * FROM payments;

-- =============================================
-- 1. Update the categories table
-- =============================================

-- Rename columns to match Cakezone naming convention
ALTER TABLE categories 
CHANGE COLUMN id CatID INT(20) NOT NULL AUTO_INCREMENT,
CHANGE COLUMN cat_name CategoryName TEXT NOT NULL;

-- =============================================
-- 2. Update the products table to match items table
-- =============================================

-- First rename the table (optional, uncomment if desired)
-- RENAME TABLE products TO items;

-- Add missing columns from Cakezone's items table
ALTER TABLE products
ADD COLUMN itemQuantity INT DEFAULT 0 AFTER price,
ADD COLUMN itemDescription TEXT AFTER itemQuantity,
ADD COLUMN itemServings INT DEFAULT 1 AFTER itemDescription;

-- Rename columns to match Cakezone naming convention (optional, uncomment if desired)
ALTER TABLE products 
CHANGE COLUMN id itemID INT(20) NOT NULL AUTO_INCREMENT,
CHANGE COLUMN name itemName TEXT NOT NULL,
CHANGE COLUMN price itemPrice DOUBLE NOT NULL,
CHANGE COLUMN prod_cat_id itemCategory INT(20) NOT NULL;

-- =============================================
-- 3. Update the users table to match profile table
-- =============================================

-- First rename the table (optional, uncomment if desired)
-- RENAME TABLE users TO profile;

-- Add missing columns from Cakezone's profile table
ALTER TABLE users
ADD COLUMN firstname VARCHAR(255) AFTER username,
ADD COLUMN lastname VARCHAR(255) AFTER firstname,
ADD COLUMN registrationDate DATETIME DEFAULT CURRENT_TIMESTAMP AFTER email,
ADD COLUMN userType INT DEFAULT 0 AFTER registrationDate;

-- Update existing users to have first/last names based on username
UPDATE users SET firstname = username, lastname = username WHERE firstname IS NULL;

-- Rename columns to match Cakezone naming convention (optional, uncomment if desired)
ALTER TABLE users 
CHANGE COLUMN id uid INT(20) NOT NULL AUTO_INCREMENT;

-- =============================================
-- 4. Create transactions table to match Cakezone
-- =============================================

-- Create a new transactions table that matches Cakezone's structure
CREATE TABLE transactions (
  tid VARCHAR(100) NOT NULL PRIMARY KEY,
  st VARCHAR(50) DEFAULT NULL,
  cc VARCHAR(10) DEFAULT NULL,
  amt DECIMAL(10,2) NOT NULL,
  email VARCHAR(255) DEFAULT NULL,
  items TEXT
);

-- Migrate data from payments table to transactions table
-- This is a basic migration that doesn't handle multiple items per transaction
INSERT INTO transactions (tid, st, cc, amt, email, items)
SELECT 
  transaction_id AS tid,
  payment_status AS st,
  'USD' AS cc,
  payment_amount AS amt,
  (SELECT email FROM users WHERE id = 1 LIMIT 1) AS email,
  CONCAT('prod_', product_id, ':1,') AS items
FROM payments
WHERE transaction_id IS NOT NULL;

-- =============================================
-- 5. Add indexes and foreign keys (if needed)
-- =============================================

-- Add foreign key constraint for products.itemCategory to categories.CatID
-- ALTER TABLE products ADD CONSTRAINT fk_product_category FOREIGN KEY (itemCategory) REFERENCES categories(CatID);

-- =============================================
-- Note: This script provides both required and optional changes.
-- Required changes add missing columns and create the transactions table.
-- Optional changes (commented out) rename tables and columns to exactly match Cakezone.
-- =============================================
