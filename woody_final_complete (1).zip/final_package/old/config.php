<?php
session_start();










$localhost = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'woody_ebus';

$conn = mysqli_connect($localhost,$user,$pass,$dbname) or die('connection to DB failed');


function query($q){
	global $conn;
	return mysqli_query($conn,$q);
}













?>