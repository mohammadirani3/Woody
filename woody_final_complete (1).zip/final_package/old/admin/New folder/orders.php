<!DOCTYPE html>
<html lang="en">

<?php 
session_start();

include("..\config.php"); 
include("header_admin.php"); 

if(!isset($_SESSION['username'])){
	header("Location:..\login.php");
}
/*
if($_SERVER['REQUEST_URI'] != "/eBusiness/Section2/eBusinessTemplateOriginal/admin/index.php" || $_SERVER['REQUEST_URI'] != "/eBusiness/Section2/eBusinessTemplateOriginal/admin") 
	
header("Location:..\login.php");


if($_SERVER['REQUEST_URI'] != "/eBusiness/Section2/eBusinessTemplateOriginal/login.php")
header("Location:login.php");

*/


?>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include("nav_top_admin.php"); ?>
            <?php include("nav_side_admin.php"); ?>
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">


                


        <div class="col-md-12">
<div class="row">
<h1 class="page-header">
   All Orders

</h1>
</div>

<div class="row">
<table class="table table-hover">
    <thead>

      <tr>
           <th>Transaction #</th>
           <th>Currency</th>
           <th>Amount</th>
           <th>Status</th>
           <th>Paypal ID</th>
           <th>Items</th>
      </tr>
    </thead>
    <tbody>
	<?php
		$q = "select * from trans";
		$result = query($q);
		while($row=mysqli_fetch_array($result)){
			$str = substr($row[5],1);
			$itemsArray = explode(";",$str);
			$itemLinks = "";
			foreach($itemsArray as $key => $value){
				if($key == count($itemsArray) - 1)
					break;
				$itemArr = explode(":", $value);
				$ID = substr($itemArr[0],4);
				$itemLinks = $itemLinks . "<a href=\"..\item.php?itemid=$ID\">$itemArr[0]</a> : " . $itemArr[1] . "<br/>";				
			}
			$tableRow = <<<DELIMETER
			<tr>
				<td>$row[0]</td>
				<td>$row[1]</td>
				<td>$row[2]</td>
				<td>$row[3]</td>
				<td>$row[4]</td>
				<td>$itemLinks</td>
			</tr>
		DELIMETER;
		echo $tableRow;
		}
	?>

    </tbody>
</table>
</div>











            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
