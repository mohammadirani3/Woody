<?php
session_start();










$localhost = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'woody_ebus';

$conn = mysqli_connect($localhost,$user,$pass,$dbname) or die('connection to DB failed');


function query($q){
	global $conn;
	return mysqli_query($conn,$q);
}

function getSideCategories(){
	return query('select * from categories');
}


function getSideOrders(){
	return query('select * from payments');
}

function getSideProducts(){
	return query('select * from products');
}


function getSideUsers(){
	return query('select * from users');
}




function check($result){
	global $conn;
	if(!$result){
		echo mysqli_error($conn);
	}
}

function userLogin(){
	$user = $_POST['username'];
	$pass = $_POST['password'];
	
	$result = query("select * from users where username = '{$user}' and password = '{$pass}'");
	
	if(mysqli_num_rows($result) == 0){
		setMessage("Username or password are incorrect!!!");
	}else{
		$row = mysqli_fetch_array($result);
		$_SESSION['username'] = $user;
		$_SESSION['email'] = $row[3];
		$_SESSION['admin'] = $row[4];
		
	
	  
	  
	  
		if($row[4] == '1'){
			
			
			
			header("Location:admin/index.php");
		}else{
			header("Location:index.php");
		}
	}
}

function setMessage($msg){
	$_SESSION['message'] = $msg;
}

function showMessage(){
		echo $_SESSION['message'];
		unset($_SESSION['message']);
}


function sendMail(){
	$from 		= $_POST['name'];
	$subject 	= $_POST['subject'];
	$msg 		= "You have a new email from: $from<br/>" . $_POST['message'];
	
	return mail('info@woody.com',$subject,$msg);
}


function printAllUsers(){
	$result = query("select * from users");
	while($row = mysqli_fetch_array($result)){
		if($row[4] == 1)
			$admin = "YES";
		else
			$admin = "NO";
		
	$a = <<< DELIMETER
	
	<tr>
		<td>$row[0]</td>
		<td>$row[1]</td>
		<td>$row[2]</td>
		<td>$row[4]</td>
		
		<td>$admin</td>
	</tr>
	
	DELIMETER;
	
	echo $a;
	}
}


















?>