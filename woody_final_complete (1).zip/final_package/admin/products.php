<!DOCTYPE html>
<html lang="en">

<?php 
require_once('..\config.php');
include("header_admin.php"); 

?>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include("nav_top_admin.php"); ?>
            <?php include("nav_side_admin.php"); ?>
        </nav>



        <div id="page-wrapper">

            <div class="container-fluid">

            

            

<h1 class="page-header">
 Products

</h1>



<div class="col-md-4">
    
    <form action="" method="get">
    
	
	<div class="form-group">
                   <label for="category-title">Category</label>

        <select name="prod_cat_id" id="" class="form-control">
            <option value="">Select Category</option>
           <?php
		   
		   $result = getSideCategories();
		   while($row = mysqli_fetch_array($result)){
			   echo "<option>$row[0] - $row[1]</option>";
		   }
		   
		   ?>
        </select>
		</div>
		
		
		
		
     
		
		
		<div class="form-group">
            <label for="category-title">Name</label>
            <input type="text" name="prod_name" class="form-control">
        </div>
		
		<div class="form-group">
            <label for="category-title">Price</label>
            <input type="text" name="prod_price" class="form-control">
        </div>
		
	
		
	
		
		



		
		

        <div class="form-group">
            
            <input type="submit" name="submit" class="btn btn-primary" value="Add Product">
        </div>      


    </form>
<?php
if(isset($_GET['submit'])){

$prod_name 	= $_GET['prod_name'];
$prod_price 	= $_GET['prod_price'];
$prod_cat_id 	= $_GET['prod_cat_id'];


$q = "insert into products(name,price,prod_cat_id) values('$prod_name','$prod_price','$prod_cat_id')";
$result = query($q);
}
?>

</div>


<div class="col-md-8">

    <table class="table">
            <thead>

        <tr>
            <th>id</th>
            <th>Name</th>
            <th>Price</th>
           
            <th>Category</th>
            <th>Delete</th>
        </tr>
            </thead>


    <tbody>
        <?php
		
			$result = getSideProducts();
			while($row= mysqli_fetch_array($result)){
				
				$cat_id = $row[3];
				$q1 = "select * from categories where id='$cat_id'";
				$result1 = query($q1);
				$row1= mysqli_fetch_array($result1);
				$cat_name = $row1['cat_name'];
				
				
				
				
				$a = <<<DELIMETER
				<tr>
					<td>$row[0]</td>
					<td>$row[1]</td>
					<td>$row[2]</td>
				
					<td>$cat_name</td>
					<td><a href="delete-product.php?ID=$row[0]">Delete</a></td>
					
				</tr>
				DELIMETER;
		
		echo $a;
			}
		?>
    </tbody>

        </table>

</div>



                













            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
