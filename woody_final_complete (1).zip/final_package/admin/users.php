<!DOCTYPE html>
<html lang="en">

<?php 
require_once('..\config.php');
include("header_admin.php"); 

?>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php include("nav_top_admin.php"); ?>
            <?php include("nav_side_admin.php"); ?>
        </nav>



        <div id="page-wrapper">

            <div class="container-fluid">

            

            

<h1 class="page-header">
  Users

</h1>



<div class="col-md-4">
    
    <form action="" method="get">
    
	
	
		
		
     
		
		
		<div class="form-group">
            <label for="category-title">Username</label>
            <input type="text" name="username" class="form-control">
        </div>
		
		<div class="form-group">
            <label for="category-title">Password</label>
            <input type="password" name="password" class="form-control">
        </div>
		
		<div class="form-group">
            <label for="category-title">Email</label>
            <input type="email" name="email" class="form-control">
        </div>
		
		
		<div class="form-group">
                   <label for="category-title">Admin</label>

        <select name="admin" id="" class="form-control">
            <option value="">Select</option>
           <option value="1">True</option>
           <option value="0">False</option>
		  
        </select>
		</div>
		
		
		
		



		
		

        <div class="form-group">
            
            <input type="submit" name="submit" class="btn btn-primary" value="Add User">
        </div>      


    </form>
<?php
if(isset($_GET['submit'])){

$username 	= $_GET['username'];
$password 	= $_GET['password'];
$email 	= $_GET['email'];
$admin 	= $_GET['admin'];


$q = "insert into users(username,password,email,admin) values('$username','$password','$email','$admin')";
$result = query($q);
}
?>

</div>


<div class="col-md-8">

    <table class="table">
            <thead>

        <tr>
            <th>id</th>
            <th>Username</th>
            <th>Password</th>
            <th>Email</th>
            <th>Admin</th>
            <th>Delete</th>
        </tr>
            </thead>


    <tbody>
        <?php
		
			$result = getSideUsers();
			while($row= mysqli_fetch_array($result)){
				
				$admin = $row[4];
				if ($admin=='1'){
					
					$admin_status = 'True';
				}else{
					
					$admin_status = 'False';

				}
				
				
				
				
				$a = <<<DELIMETER
				<tr>
					<td>$row[0]</td>
					<td>$row[1]</td>
					<td>$row[2]</td>
					<td>$row[3]</td>
					<td>$admin_status</td>
					<td><a href="delete-user.php?ID=$row[0]">Delete</a></td>
					
				</tr>
				DELIMETER;
		
		echo $a;
			}
		?>
    </tbody>

        </table>

</div>



                













            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>

</body>

</html>
