<div class="collapse navbar-collapse navbar-ex1-collapse">
	<ul class="nav navbar-nav side-nav">
		<li class="active">
			<a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
		</li>
		
			<li>
			<a href="categories.php"><i class="fa fa-fw fa-desktop"></i> Categories</a>
		</li>
		
		
		
		<li>
			<a href="products.php"><i class="fa fa-fw fa-bar-chart-o"></i>  Products</a>
		</li>
		
		
	
		<li>
			<a href="users.php"><i class="fa fa-fw fa-user"></i>Users</a>
		</li>
		
		
		<li>
			<a href="orders.php"><i class="fa fa-fw fa-wrench"></i>Orders</a>
		</li>
	
	</ul>
</div>