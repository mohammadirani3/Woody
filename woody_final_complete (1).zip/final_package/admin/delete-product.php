<?php
session_start();

$ID=$_GET['ID'];

require_once('../config.php');


$q = "delete from products where id='$ID'";

query($q);


echo "<script language='JavaScript'>
document.location='products.php';
</script>";

?>