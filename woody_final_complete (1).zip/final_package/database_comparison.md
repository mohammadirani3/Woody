# Database Schema Comparison: Cakezone vs Woody

## Cakezone Database (cakeDB)
Based on code references in config.php, Cakezone uses the following tables:

1. **categories**
   - CatID (primary key)
   - CategoryName

2. **items**
   - itemID (primary key)
   - itemName
   - itemPrice
   - itemQuantity
   - itemDescription
   - itemServings
   - itemCategory (foreign key to categories.CatID)

3. **profile**
   - uid (primary key)
   - firstname
   - lastname
   - registrationDate
   - userType
   - username (implied from login code)
   - password (implied from login code)

4. **transactions**
   - tid (primary key)
   - amt (amount)
   - cc (currency code)
   - email
   - items (comma-separated list of items)

## Woody Database (woody_ebus)
Based on woody_ebus.sql, Woody uses the following tables:

1. **categories**
   - id (primary key, auto_increment)
   - cat_name

2. **products**
   - id (primary key, auto_increment)
   - name
   - price
   - prod_cat_id (foreign key to categories.id)

3. **users**
   - id (primary key, auto_increment)
   - username
   - password
   - email
   - admin (integer flag)

4. **payments**
   - id (primary key, auto_increment)
   - product_id (foreign key to products.id)
   - payment_amount
   - payment_status
   - transaction_id
   - payment_date

## Key Differences

### Table Name Differences
- Cakezone: "items" vs Woody: "products"
- Cakezone: "profile" vs Woody: "users"
- Cakezone: "transactions" vs Woody: "payments"

### Column Name Differences
1. **categories**:
   - Cakezone: "CatID" vs Woody: "id"
   - Cakezone: "CategoryName" vs Woody: "cat_name"

2. **items/products**:
   - Cakezone: "itemID" vs Woody: "id"
   - Cakezone: "itemName" vs Woody: "name"
   - Cakezone: "itemPrice" vs Woody: "price"
   - Cakezone: "itemCategory" vs Woody: "prod_cat_id"
   - Cakezone has additional columns: "itemQuantity", "itemDescription", "itemServings"

3. **profile/users**:
   - Cakezone: "uid" vs Woody: "id"
   - Cakezone has "firstname", "lastname", "registrationDate", "userType"
   - Woody has "email", "admin" flag

4. **transactions/payments**:
   - Completely different structure:
     - Cakezone stores transaction ID, amount, currency, email, and a comma-separated list of items
     - Woody stores payment ID, product ID, amount, status, transaction ID, and date

## Required Updates for Woody

1. **products table**:
   - Add columns: "itemQuantity", "itemDescription", "itemServings"
   - Rename to match Cakezone naming convention (optional)

2. **users table**:
   - Add columns: "firstname", "lastname", "registrationDate", "userType"
   - Rename to match Cakezone naming convention (optional)

3. **payments table**:
   - Restructure to match Cakezone's transactions table
   - Add support for multiple items per transaction

4. **Column naming**:
   - Update column names to match Cakezone's naming convention (optional)
