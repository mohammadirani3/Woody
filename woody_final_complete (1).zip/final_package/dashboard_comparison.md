# Dashboard Comparison Notes

**Cakezone Dashboard (`cakezone/admin/index.php`):**
- Uses SB Admin 2 template.
- Includes `adminTopBar.php`, `adminSideBar.php`, `adminFooter.php`.
- Displays "Dashboard" heading.
- Includes a static "Generate Report" button.
- Includes `adminCards.php`: 4 summary cards (Earnings Monthly, Earnings Annual, Tasks, Pending Requests) with static data and icons.
- Includes `adminCharts.php`: Area Chart and Pie Chart placeholders (using Chart.js with demo data).

**Woody Dashboard (`woody/admin/index.php`):**
- Uses a simpler, older Bootstrap template.
- Includes `header_admin.php`, `nav_top_admin.php`, `nav_side_admin.php`.
- Displays "Admin" heading via `page_header_admin.php`.
- Includes `panels_admin.php`: 3 summary panels (New Orders, Products, Categories) with dynamic data counts but simpler styling and no icons.

**Key Differences/Missing Features in Woody:**
- Lacks the SB Admin 2 template structure and styling.
- Missing the "Generate Report" button.
- Missing the specific 4 summary cards with icons (has 3 different panels).
- Missing the Area Chart.
- Missing the Pie Chart.
- Missing Chart.js integration and associated demo scripts.

